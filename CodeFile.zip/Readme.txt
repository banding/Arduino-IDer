This software comes with no warranties of any kind. Use this program at your own risk.
It is intended for Ham Radio non-commercial use only. 
All right are reserved. 
This is a small command line utility program to encode a user entered string. The text is meant to be used as a message in the Arduino Ider sketch. 
Run the program enter a plain text message. The program will generate a text file using hex codes. Copy and paste the hex codes into the Arduino Ider sketch (message line).
